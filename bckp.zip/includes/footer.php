	
	</div>
</body>
	 <!-- Form Validate -->
	<script src="js/jquery.validate.min.js" type="text/javascript"></script>
	<?php include_once("./js/utils.inc");//utility functions?>
</html>