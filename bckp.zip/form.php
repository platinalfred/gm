<!DOCTYPE html>
<html>

<head>
    <title>
        hightop - Dashboard
    </title>
    <link href="http://fonts.googleapis.com/css?family=Lato:100,300,400,700" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/bootstrap.min.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/font-awesome.min.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/hightop-font.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/isotope.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/jquery.fancybox.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/fullcalendar.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/wizard.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/select2.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/morris.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/datatables.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/datepicker.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/timepicker.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/colorpicker.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/bootstrap-switch.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/bootstrap-editable.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/daterange-picker.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/typeahead.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/summernote.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/ladda-themeless.min.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/social-buttons.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/jquery.fileupload-ui.css" media="screen" rel="stylesheet" type="text/css" />
    <link href="stylesheets/dropzone.css" media="screen" rel="stylesheet" type="text/css" />
    <link href="stylesheets/nestable.css" media="screen" rel="stylesheet" type="text/css" />
    <link href="stylesheets/pygments.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/style.css" media="all" rel="stylesheet" type="text/css" />
    <link href="stylesheets/color/green.css" media="all" rel="alternate stylesheet" title="green-theme" type="text/css" />
    <link href="stylesheets/color/orange.css" media="all" rel="alternate stylesheet" title="orange-theme" type="text/css" />
    <link href="stylesheets/color/magenta.css" media="all" rel="alternate stylesheet" title="magenta-theme" type="text/css" />
    <link href="stylesheets/color/gray.css" media="all" rel="alternate stylesheet" title="gray-theme" type="text/css" />
    <script src="http://code.jquery.com/jquery-1.10.2.min.js" type="text/javascript"></script>
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js" type="text/javascript"></script>
    <script src="javascripts/bootstrap.min.js" type="text/javascript"></script>
    <script src="javascripts/raphael.min.js" type="text/javascript"></script>
    <script src="javascripts/selectivizr-min.js" type="text/javascript"></script>
    <script src="javascripts/jquery.mousewheel.js" type="text/javascript"></script>
    <script src="javascripts/jquery.vmap.min.js" type="text/javascript"></script>
    <script src="javascripts/jquery.vmap.sampledata.js" type="text/javascript"></script>
    <script src="javascripts/jquery.vmap.world.js" type="text/javascript"></script>
    <script src="javascripts/jquery.bootstrap.wizard.js" type="text/javascript"></script>
    <script src="javascripts/fullcalendar.min.js" type="text/javascript"></script>
    <script src="javascripts/gcal.js" type="text/javascript"></script>
    <script src="javascripts/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="javascripts/datatable-editable.js" type="text/javascript"></script>
    <script src="javascripts/jquery.easy-pie-chart.js" type="text/javascript"></script>
    <script src="javascripts/excanvas.min.js" type="text/javascript"></script>
    <script src="javascripts/jquery.isotope.min.js" type="text/javascript"></script>
    <script src="javascripts/isotope_extras.js" type="text/javascript"></script>
    <script src="javascripts/modernizr.custom.js" type="text/javascript"></script>
    <script src="javascripts/jquery.fancybox.pack.js" type="text/javascript"></script>
    <script src="javascripts/select2.js" type="text/javascript"></script>
    <script src="javascripts/styleswitcher.js" type="text/javascript"></script>
    <script src="javascripts/wysiwyg.js" type="text/javascript"></script>
    <script src="javascripts/typeahead.js" type="text/javascript"></script>
    <script src="javascripts/summernote.min.js" type="text/javascript"></script>
    <script src="javascripts/jquery.inputmask.min.js" type="text/javascript"></script>
    <script src="javascripts/jquery.validate.js" type="text/javascript"></script>
    <script src="javascripts/bootstrap-fileupload.js" type="text/javascript"></script>
    <script src="javascripts/bootstrap-datepicker.js" type="text/javascript"></script>
    <script src="javascripts/bootstrap-timepicker.js" type="text/javascript"></script>
    <script src="javascripts/bootstrap-colorpicker.js" type="text/javascript"></script>
    <script src="javascripts/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="javascripts/typeahead.js" type="text/javascript"></script>
    <script src="javascripts/spin.min.js" type="text/javascript"></script>
    <script src="javascripts/ladda.min.js" type="text/javascript"></script>
    <script src="javascripts/moment.js" type="text/javascript"></script>
    <script src="javascripts/mockjax.js" type="text/javascript"></script>
    <script src="javascripts/bootstrap-editable.min.js" type="text/javascript"></script>
    <script src="javascripts/xeditable-demo-mock.js" type="text/javascript"></script>
    <script src="javascripts/xeditable-demo.js" type="text/javascript"></script>
    <script src="javascripts/address.js" type="text/javascript"></script>
    <script src="javascripts/daterange-picker.js" type="text/javascript"></script>
    <script src="javascripts/date.js" type="text/javascript"></script>
    <script src="javascripts/morris.min.js" type="text/javascript"></script>
    <script src="javascripts/skycons.js" type="text/javascript"></script>
    <script src="javascripts/fitvids.js" type="text/javascript"></script>
    <script src="javascripts/jquery.sparkline.min.js" type="text/javascript"></script>
    <script src="javascripts/dropzone.js" type="text/javascript"></script>
    <script src="javascripts/jquery.nestable.js" type="text/javascript"></script>
    <script src="javascripts/main.js" type="text/javascript"></script>
    <script src="javascripts/respond.js" type="text/javascript"></script>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport">
</head>

<body class="page-header-fixed bg-1">
    <div class="modal-shiftfix">
        <!-- Navigation -->
        <div class="navbar navbar-fixed-top scroll-hide">
            <div class="container-fluid top-bar">
                <div class="pull-right">
                    <ul class="nav navbar-nav pull-right">
                        <li class="dropdown notifications hidden-xs">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span aria-hidden="true" class="hightop-flag"></span>
                  <div class="sr-only">
                    Notifications
                  </div>
                  <p class="counter">
                    4
                  </p>
                </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#">
                                        <div class="notifications label label-info">
                                            New
                                        </div>
                                        <p>
                                            New user added: Jane Smith
                                        </p>
                                    </a>

                                </li>
                                <li>
                                    <a href="#">
                                        <div class="notifications label label-info">
                                            New
                                        </div>
                                        <p>
                                            Sales targets available
                                        </p>
                                    </a>

                                </li>
                                <li>
                                    <a href="#">
                                        <div class="notifications label label-info">
                                            New
                                        </div>
                                        <p>
                                            New performance metric added
                                        </p>
                                    </a>

                                </li>
                                <li>
                                    <a href="#">
                                        <div class="notifications label label-info">
                                            New
                                        </div>
                                        <p>
                                            New growth data available
                                        </p>
                                    </a>

                                </li>
                            </ul>
                        </li>
                        <li class="dropdown messages hidden-xs">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span aria-hidden="true" class="hightop-envelope"></span>
                  <div class="sr-only">
                    Messages
                  </div>
                  <p class="counter">
                    3
                  </p>
                </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#">
                                        <img width="34" height="34" src="images/avatar-male2.png" />Could we meet today? I wanted...</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img width="34" height="34" src="images/avatar-female.png" />Important data needs your analysis...</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img width="34" height="34" src="images/avatar-male2.png" />Buy Se7en today, it's a great theme...</a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown user hidden-xs">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <img width="34" height="34" src="images/avatar-male.jpg" />John Smith<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="#">
                                        <i class="fa fa-user"></i>My Account</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-gear"></i>Account Settings</a>
                                </li>
                                <li>
                                    <a href="login1.html">
                                        <i class="fa fa-sign-out"></i>Logout</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <button class="navbar-toggle"><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button><a class="logo" href="index.html">Hightop</a>
                <form class="navbar-form form-inline col-lg-2 hidden-xs">
                    <input class="form-control" placeholder="Search" type="text">
                </form>
            </div>
            <div class="container-fluid main-nav clearfix">
                <div class="nav-collapse">
                    <ul class="nav">
                        <li>
                            <a href="index.html"><span aria-hidden="true" class="hightop-home"></span>Dashboard</a>
                        </li>
                        <li>
                            <a href="social.html">
                                <span aria-hidden="true" class="hightop-feed"></span>Social Feed</a>
                        </li>
                        <li class="dropdown">
                            <a data-toggle="dropdown" href="#">
                                <span aria-hidden="true" class="hightop-star"></span>UI Features<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="buttons.html">Buttons</a>
                                </li>
                                <li>
                                    <a href="fontawesome.html">Font Awesome Icons</a>
                                </li>
                                <li>
                                    <a href="glyphicons.html">Glyphicons</a>
                                </li>
                                <li>
                                    <a href="components.html">Components</a>
                                </li>
                                <li>
                                    <a href="widgets.html">Widgets</a>
                                </li>
                                <li>
                                    <a href="nestable-lists.html">Nestable Lists</a>
                                </li>
                                <li>
                                    <a href="typo.html">Typography</a>
                                </li>
                                <li>
                                    <a href="grid.html">Grid Layout</a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown current">
                            <a data-toggle="dropdown" class="current" href="#">
                                <span aria-hidden="true" class="hightop-forms"></span>Forms<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="current" href="form-components.html">Form Components</a>
                                </li>
                                <li>
                                    <a href="form-advanced.html">Advanced Forms</a>
                                </li>
                                <li>
                                    <a href="xeditable.html">X-Editable</a>
                                </li>
                                <li>
                                    <a href="file-upload.html">Multiple File Upload</a>
                                </li>
                                <li>
                                    <a href="dropzone-file-upload.html">Dropzone File Upload</a>
                                </li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a data-toggle="dropdown" href="#">
                                <span aria-hidden="true" class="hightop-tables"></span>Tables<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="tables.html">Basic tables</a>
                                </li>
                                <li>
                                    <a href="datatables.html">DataTables</a>
                                </li>
                                <li>
                                    <a href="datatables-editable.html">Editable DataTables</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="charts.html">
                                <span aria-hidden="true" class="hightop-charts"></span>Charts</a>
                        </li>
                        <li class="dropdown">
                            <a data-toggle="dropdown" href="#">
                                <span aria-hidden="true" class="hightop-pages"></span>Pages<b class="caret"></b></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="chat.html">Chat</a>
                                </li>
                                <li>
                                    <a href="calendar.html">Calendar</a>
                                </li>
                                <li>
                                    <a href="timeline.html">Timeline</a>
                                </li>
                                <li>
                                    <a href="login1.html">Login 1</a>
                                </li>
                                <li>
                                    <a href="login2.html">Login 2</a>
                                </li>
                                <li>
                                    <a href="messages.html">Messages/Inbox</a>
                                </li>
                                <li>
                                    <a href="pricing.html">Pricing Tables</a>
                                </li>
                                <li>
                                    <a href="signup1.html">Sign Up 1</a>
                                </li>
                                <li>
                                    <a href="signup2.html">Sign Up 2</a>
                                </li>
                                <li>
                                    <a href="invoice.html">Invoice</a>
                                </li>
                                <li>
                                    <a href="faq.html">FAQ</a>
                                </li>
                                <li>
                                    <a href="filters.html">Filter Results</a>
                                </li>
                                <li>
                                    <a href="404-page.html">404 Page</a>
                                </li>
                                <li>
                                    <a href="500-page.html">500 Error</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="gallery.html">
                                <span aria-hidden="true" class="hightop-gallery"></span>Gallery</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End Navigation -->
        <div class="container-fluid main-content">
            <div class="page-title">
                <h1>
    Form Components
  </h1>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget-container fluid-height clearfix">
                        <div class="heading">
                            <i class="fa fa-bars"></i>Basic Components
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">Input</label>
                                    <div class="col-md-7">
                                        <input class="form-control" placeholder="Text" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Dropdown</label>
                                    <div class="col-md-7">
                                        <select class="form-control">
                                            <option value="Category 1">Option 1</option>
                                            <option value="Category 2">Option 2</option>
                                            <option value="Category 3">Option 3</option>
                                            <option value="Category 4">Option 4</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Multi-Select</label>
                                    <div class="col-md-7">
                                        <select class="form-control" multiple="">
                                            <option value="Category 1">Option 1</option>
                                            <option value="Category 2">Option 2</option>
                                            <option value="Category 3">Option 3</option>
                                            <option value="Category 4">Option 4</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Username Input</label>
                                    <div class="col-md-7">
                                        <div class="input-group">
                                            <span class="input-group-addon">@</span>
                                            <input class="form-control" placeholder="Username" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Currency Input</label>
                                    <div class="col-md-7">
                                        <div class="input-group">
                                            <span class="input-group-addon">$</span>
                                            <input class="form-control" type="text"><span class="input-group-addon">.00</span></input>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Button Add-on</label>
                                    <div class="col-md-7">
                                        <div class="input-group">
                                            <input class="form-control" type="text"><span class="input-group-btn"><button class="btn btn-default" type="button">Go</button></span></input>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Dropdown Add-on</label>
                                    <div class="col-md-7">
                                        <div class="input-group">
                                            <input class="form-control" type="text">
                                            <div class="input-group-btn">
                                                <button class="btn btn-default dropdown-toggle" data-toggle="dropdown" type="button">Actions<span class="caret"></span></button>
                                                <ul class="dropdown-menu pull-right">
                                                    <li>
                                                        <a href="#">Action 1</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Action 2</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Action 3</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            </input>
                                        </div>
                                    </div>
                                </div>
                                <fieldset disabled="">
                                    <div class="form-group">
                                        <label class="control-label col-md-2" for="disabledInput">Disabled Input</label>
                                        <div class="col-md-7">
                                            <input class="form-control" id="disabledInput" placeholder="Disabled input" type="text">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="control-label col-md-2" for="disabledInput">Disabled Select</label>
                                        <div class="col-md-7">
                                            <select class="form-control" id="disabledSelect">
                                                <option>Disabled select</option>
                                            </select>
                                        </div>
                                    </div>
                                </fieldset>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Radio Buttons</label>
                                    <div class="col-md-7">
                                        <label class="radio" for="option1">
                                            <input id="option1" name="optionsRadios1" type="radio" value="option1"><span>Option 1</span></label>
                                        <label class="radio">
                                            <input checked="" name="optionsRadios1" type="radio" value="option2"><span>Option 2</span></label>
                                        <label class="radio">
                                            <input name="optionsRadios1" type="radio" value="option3"><span>Option 3</span></label>
                                        <label class="radio">
                                            <input name="optionsRadios1" type="radio" value="option4"><span>Option 4</span></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Radio Buttons</label>
                                    <div class="col-md-7">
                                        <label class="radio-inline">
                                            <input name="optionsRadios2" type="radio" value="option1"><span>Option 1</span></label>
                                        <label class="radio-inline">
                                            <input checked="" name="optionsRadios2" type="radio" value="option2"><span>Option 2</span></label>
                                        <label class="radio-inline">
                                            <input name="optionsRadios2" type="radio" value="option3"><span>Option 3</span></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Checkbox</label>
                                    <div class="col-md-7">
                                        <label class="checkbox">
                                            <input type="checkbox"><span>Checkbox 1</span></label>
                                        <label class="checkbox">
                                            <input type="checkbox"><span>Checkbox 2</span></label>
                                        <label class="checkbox">
                                            <input type="checkbox"><span>Checkbox 3</span></label>
                                        <label class="checkbox">
                                            <input type="checkbox"><span>Checkbox 4</span></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Checkbox</label>
                                    <div class="col-md-7">
                                        <label class="checkbox-inline">
                                            <input type="checkbox"><span>Checkbox 1</span></label>
                                        <label class="checkbox-inline">
                                            <input type="checkbox"><span>Checkbox 2</span></label>
                                        <label class="checkbox-inline">
                                            <input type="checkbox"><span>Checkbox 3</span></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Textarea</label>
                                    <div class="col-md-7">
                                        <textarea class="form-control" rows="3"></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Form Actions</label>
                                    <div class="col-md-7">
                                        <button class="btn btn-primary" type="submit">Submit</button>
                                        <button class="btn btn-default-outline">Cancel </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget-container fluid-height clearfix">
                        <div class="heading">
                            <i class="fa fa-toggle-down"></i>Select2 Dropdowns
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">Select2 Dropdown</label>
                                    <div class="col-md-7">
                                        <select class="select2able">
                                            <option value="Category 1">Option 1</option>
                                            <option value="Category 2">Option 2</option>
                                            <option value="Category 3">Option 3</option>
                                            <option value="Category 4">Option 4</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Multi-Select2</label>
                                    <div class="col-md-7">
                                        <select class="select2able" multiple="">
                                            <option value="Category 1">Option 1</option>
                                            <option value="Category 2">Option 2</option>
                                            <option value="Category 3">Option 3</option>
                                            <option value="Category 4">Option 4</option>
                                        </select>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget-container fluid-height clearfix">
                        <div class="heading">
                            <i class="fa fa-comment"></i>Autocomplete
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">U.S. States</label>
                                    <div class="col-md-7">
                                        <input autocomplete="off" class="form-control states typeahead tt-query" dir="auto" placeholder="Search for a U.S. state" spellcheck="false" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Countries</label>
                                    <div class="col-md-7">
                                        <input autocomplete="off" class="form-control countries typeahead tt-query" dir="auto" placeholder="Search for a country" spellcheck="false" type="text">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget-container fluid-height clearfix">
                        <div class="heading">
                            <i class="fa fa-check"></i>Toggle Switches
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">Switch Sizes</label>
                                    <div class="col-md-7">
                                        <div class="toggle-switch switch-large">
                                            <input checked="" type="checkbox">
                                        </div>
                                        <div class="toggle-switch">
                                            <input checked="" type="checkbox">
                                        </div>
                                        <div class="toggle-switch switch-small">
                                            <input checked="" type="checkbox">
                                        </div>
                                        <div class="toggle-switch switch-mini">
                                            <input checked="" type="checkbox">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Switch Colors</label>
                                    <div class="col-md-7">
                                        <div class="toggle-switch" data-off="info" data-on="primary">
                                            <input checked="" type="checkbox">
                                        </div>
                                        <div class="toggle-switch" data-off="success" data-on="info">
                                            <input checked="" type="checkbox">
                                        </div>
                                        <div class="toggle-switch" data-off="warning" data-on="success">
                                            <input checked="" type="checkbox">
                                        </div>
                                        <div class="toggle-switch" data-off="danger" data-on="warning">
                                            <input checked="" type="checkbox">
                                        </div>
                                        <div class="toggle-switch" data-off="default" data-on="danger">
                                            <input checked="" type="checkbox">
                                        </div>
                                        <div class="toggle-switch" data-off="primary" data-on="default">
                                            <input checked="" type="checkbox">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Different Labels</label>
                                    <div class="col-md-7">
                                        <div class="toggle-switch text-toggle-switch" data-off-label="GOODBYE" data-on="primary" data-on-label="HELLO" style="width:200px;">
                                            <input checked="" type="checkbox">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Authentic Toggle Switch</label>
                                    <div class="col-md-7 clearfix">
                                        <div class="holder">
                                            <input checked="checked" class="check-ios" id="check" name="check" type="checkbox" value="None">
                                            <label for="check"></label><span></span>
                                        </div>
                                        <em>(works only in modern browsers)</em>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="widget-container">
                        <div class="heading">
                            <i class="fa fa-shield"></i>Form Validation
                        </div>
                        <div class="widget-content padded">
                            <form action="" id="validate-form" method="get">
                                <fieldset>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="firstname">First Name</label>
                                                <input class="form-control" id="firstname" name="firstname" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label for="username">Username</label>
                                                <input class="form-control" id="username" name="username" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label for="password">Password</label>
                                                <input class="form-control" id="password" name="password" type="password">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="lastname">Last Name</label>
                                                <input class="form-control" id="lastname" name="lastname" type="text">
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Email</label>
                                                <input class="form-control" id="email" name="email" type="email">
                                            </div>
                                            <div class="form-group">
                                                <label for="confirm_password">Confirm Password</label>
                                                <input class="form-control" id="confirm_password" name="confirm_password" type="password">
                                            </div>
                                        </div>
                                    </div>
                                    <input class="btn btn-primary" type="submit" value="Validate form">
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="widget-container">
                        <div class="heading">
                            <i class="fa fa-shield"></i>Validation States
                        </div>
                        <div class="widget-content padded">
                            <div class="row">
                                <form class="col-md-6">
                                    <div class="form-group has-warning">
                                        <label class="control-label" for="inputWarning">Warning</label>
                                        <input class="form-control" id="inputWarning" type="text">
                                    </div>
                                    <div class="form-group has-error">
                                        <label class="control-label" for="inputError">Error</label>
                                        <input class="form-control" id="inputError" type="text">
                                    </div>
                                    <div class="form-group has-success">
                                        <label class="control-label" for="inputSuccess">Success</label>
                                        <input class="form-control" id="inputSuccess" type="text">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget-container fluid-height clearfix">
                        <div class="heading">
                            <i class="fa fa-calendar"></i>Date Pickers
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">Default</label>
                                    <div class="col-md-3">
                                        <input class="form-control datepicker" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">As a Component</label>
                                    <div class="col-md-3">
                                        <div class="input-group date datepicker">
                                            <input class="form-control" type="text"><span class="input-group-addon"><i class="fa fa-calendar"></i></span></input>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Autoclose</label>
                                    <div class="col-md-3">
                                        <div class="input-group date datepicker" data-date-autoclose="true" data-date-format="dd-mm-yyyy">
                                            <input class="form-control" type="text"><span class="input-group-addon"><i class="fa fa-calendar"></i></span></input>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Start With the Year</label>
                                    <div class="col-md-3">
                                        <div class="input-group date datepicker" data-date-autoclose="true" data-date-format="dd.mm.yyyy" data-date-start-view="2">
                                            <input class="form-control" type="text"><span class="input-group-addon"><i class="fa fa-calendar"></i></span></input>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Date Range 1</label>
                                    <div class="col-sm-2">
                                        <input class="form-control" data-date-autoclose="true" data-date-format="dd-mm-yyyy" id="dpd1" placeholder="Start date" type="text">
                                    </div>
                                    <div class="col-sm-2">
                                        <input class="form-control" data-date-autoclose="true" data-date-format="dd-mm-yyyy" id="dpd2" placeholder="End date" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Date Range 2</label>
                                    <div class="col-md-3">
                                        <div class="input-group date">
                                            <input class="form-control date-range" type="text"><span class="input-group-addon"><i class="fa fa-calendar"></i></span></input>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget-container fluid-height clearfix">
                        <div class="heading">
                            <i class="fa fa-clock-o"></i>Time Pickers
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">Default</label>
                                    <div class="col-md-3">
                                        <div class="input-group bootstrap-timepicker">
                                            <input class="form-control" id="timepicker-default" type="text"><span class="input-group-addon"><i class="fa fa-clock-o"></i></span></input>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">24 Hour</label>
                                    <div class="col-md-3">
                                        <div class="input-group bootstrap-timepicker">
                                            <input class="form-control" id="timepicker-24h" type="text"><span class="input-group-addon"><i class="fa fa-clock-o"></i></span></input>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">No Dropdown</label>
                                    <div class="col-md-3">
                                        <div class="bootstrap-timepicker">
                                            <input class="form-control" id="timepicker-noTemplate" type="text"><i class="fa fa-clock-o"></i>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget-container fluid-height clearfix">
                        <div class="heading">
                            <i class="fa fa-tint"></i>Color Pickers
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">Default</label>
                                    <div class="col-sm-4">
                                        <input class="form-control" id="cp1" type="text" value="#8fff00">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">RGBA</label>
                                    <div class="col-sm-4">
                                        <input class="form-control" data-color-format="rgba" id="cp2" type="text" value="rgb(0,194,255,0.78)">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">As a Component</label>
                                    <div class="col-sm-4">
                                        <div class="input-group color" data-color="rgb(200, 0, 0)" data-color-format="rgb" id="cp3">
                                            <input class="form-control" readonly="" type="text" value="rgb(200, 0, 0)"><span class="input-group-addon"><i style="background-color: rgb(200, 0, 0)"></i></span></input>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="widget-container fluid-height clearfix">
                        <div class="heading">
                            <i class="fa fa-reorder"></i>Input Masks
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">Date 1</label>
                                    <div class="col-md-3">
                                        <input class="form-control" data-inputmask="'alias': 'mm/dd/yyyy'" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Date 2</label>
                                    <div class="col-md-3">
                                        <input class="form-control" data-inputmask="'alias': 'dd/mm/yyyy'" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Phone Number</label>
                                    <div class="col-md-3">
                                        <input class="form-control" data-inputmask="'mask': ['(999) 999-9999']" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Social Security #</label>
                                    <div class="col-md-3">
                                        <input class="form-control" data-inputmask="'mask': ['999-99-9999']" type="text">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="widget-container">
                        <div class="heading">
                            <i class="fa fa-cloud-upload"></i>File Upload
                        </div>
                        <div class="widget-content padded">
                            <form action="#" class="form-horizontal">
                                <div class="form-group">
                                    <label class="control-label col-md-2">Custom File Upload</label>
                                    <div class="col-md-4">
                                        <div class="fileupload fileupload-new" data-provides="fileupload">
                                            <div class="input-group">
                                                <div class="form-control">
                                                    <i class="fa fa-file fileupload-exists"></i><span class="fileupload-preview"></span>
                                                </div>
                                                <div class="input-group-btn">
                                                    <a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a><span class="btn btn-default btn-file"><span class="fileupload-new">Select file</span><span class="fileupload-exists">Change</span>
                                                    <input type="file">
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">Without Input</label>
                                    <div class="col-md-4">
                                        <div class="fileupload fileupload-new" data-provides="fileupload">
                                            <span class="btn btn-default btn-file"><span class="fileupload-new">Select file</span><span class="fileupload-exists">Change</span>
                                            <input type="file">
                                            </span><span class="fileupload-preview"></span>
                                            <button class="close fileupload-exists" data-dismiss="fileupload" style="float:none" type="button">&times;</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-2">With Preview</label>
                                    <div class="col-md-4">
                                        <div class="fileupload fileupload-new" data-provides="fileupload">
                                            <div class="fileupload-new img-thumbnail" style="width: 200px; height: 150px;">
                                                <img src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&text=no+image">
                                            </div>
                                            <div class="fileupload-preview fileupload-exists img-thumbnail" style="width: 200px; max-height: 150px"></div>
                                            <div>
                                                <span class="btn btn-default btn-file"><span class="fileupload-new">Select image</span><span class="fileupload-exists">Change</span>
                                                <input type="file">
                                                </span><a class="btn btn-default fileupload-exists" data-dismiss="fileupload" href="#">Remove</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="widget-container fluid-height">
                        <div class="heading">
                            <i class="fa fa-move"></i>Drag and Drop Upload
                        </div>
                        <div class="widget-content padded">
                            <div class="single-file-drop">
                                <h4>
            Drag and drop files here
          </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="style-selector">
        <div class="style-selector-container">
            <h2>
          Layout Style
        </h2>
            <select name="layout">
                <option value="fluid">Fluid</option>
                <option value="boxed">Boxed</option>
            </select>
            <h2>
          Navigation Style
        </h2>
            <select name="nav">
                <option value="top">Top</option>
                <option value="left">Left</option>
            </select>
            <h2>
          Color Options
        </h2>
            <ul class="color-options clearfix">
                <li>
                    <a class="blue" href="javascript:chooseStyle('none', 30)"></a>
                </li>
                <li>
                    <a class="green" href="javascript:chooseStyle('green-theme', 30)"></a>
                </li>
                <li>
                    <a class="orange" href="javascript:chooseStyle('orange-theme', 30)"></a>
                </li>
                <li>
                    <a class="magenta" href="javascript:chooseStyle('magenta-theme', 30)"></a>
                </li>
                <li>
                    <a class="gray" href="javascript:chooseStyle('gray-theme', 30)"></a>
                </li>
            </ul>
            <h2>
          Background Patterns
        </h2>
            <ul class="pattern-options clearfix">
                <li>
                    <a class="active" href="#" id="bg-1"></a>
                </li>
                <li>
                    <a href="#" id="bg-2"></a>
                </li>
                <li>
                    <a href="#" id="bg-3"></a>
                </li>
                <li>
                    <a href="#" id="bg-4"></a>
                </li>
                <li>
                    <a href="#" id="bg-5"></a>
                </li>
            </ul>
            <div class="style-toggle closed">
                <span aria-hidden="true" class="hightop-gear"></span>
            </div>
        </div>
    </div>
</body>

</html>